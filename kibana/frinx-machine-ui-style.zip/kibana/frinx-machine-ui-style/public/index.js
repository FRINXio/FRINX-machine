import 'plugins/frinx-machine-ui-style/less/main.less';

