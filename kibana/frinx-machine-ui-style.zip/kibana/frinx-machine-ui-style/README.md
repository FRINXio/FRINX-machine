# Kibana plugin for frinx machine ui style
